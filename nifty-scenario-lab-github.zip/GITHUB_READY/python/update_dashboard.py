"""
One-command dashboard refresh.
    pip install -r python/requirements.txt
    python python/update_dashboard.py

Kya karta hai:
  1) Yahoo Finance se NIFTY 50, India VIX, US VIX (CBOE), S&P 500 download karta hai (2016 se aaj tak)
  2) Features banata hai: VIX percentile (252d), 52w drawdown, 200/50-EMA distance, RSI-14, MACD, weekly MA,
     bull-count atoms, 6-month low distance, sweep recency
  3) Model fit karta hai (logistic regression) + walk-forward OOS Platt calibration
  4) 8 scenario stats (episode-level), confidence buckets, presets nikalta hai
  5) data/app_data.json likhta hai aur index.html me embed kar deta hai
"""
from __future__ import annotations
import json, re, pathlib, sys
import numpy as np, pandas as pd

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)

try:
    import yfinance as yf
except ImportError:
    sys.exit("yfinance missing -> pip install -r python/requirements.txt")
try:
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
except ImportError:
    sys.exit("scikit-learn missing -> pip install -r python/requirements.txt")

TICKERS = {"^NSEI": "NIFTY", "^INDIAVIX": "INDIAVIX", "^VIX": "USVIX", "^GSPC": "SPX"}
START = "2016-12-01"

print("[1/5] downloading data ...")
raw = {}
for t, name in TICKERS.items():
    d = yf.download(t, start=START, progress=False, auto_adjust=False)
    if isinstance(d.columns, pd.MultiIndex):
        d.columns = [c[0] for c in d.columns]
    raw[name] = d[["Open", "High", "Low", "Close", "Volume"]].rename(columns=lambda c: f"{name}_{c}")
df = None
for k, v in raw.items():
    df = v if df is None else df.join(v, how="outer")
df.to_csv(DATA / "master.csv")

# ---------- align on the Indian trading calendar; US data ffill (US close precedes India open) ----------
df = df.sort_index()
df = df.reindex(df.index[df["NIFTY_Close"].notna()]).ffill(limit=5)
df["NIFTY_Close"] = df["NIFTY_Close"].ffill()
N = df["NIFTY_Close"]

print("[2/5] building features ...")
def rsi(s, n=14):
    d = s.diff()
    up = d.clip(lower=0).ewm(alpha=1/n, adjust=False).mean()
    dn = (-d).clip(lower=0).ewm(alpha=1/n, adjust=False).mean()
    return 100 - 100/(1 + up/dn)

def pct_rank(s, win, minp=60):
    return s.rolling(win, min_periods=minp).apply(lambda x: (x[-1] > x[:-1]).mean()*100, raw=True)

F = pd.DataFrame(index=df.index)
F["NIFTY"] = N
F["INDIAVIX"] = df["INDIAVIX_Close"]
# FIX (look-ahead): India 3:30 PM IST par band hota hai, US close us raat aata hai.
# Isliye US VIX ko 1 din shift karke use karo (pichhla US close hi India open se pehle available tha).
F["USVIX"] = df["USVIX_Close"].shift(1)
F["n_rsi14"] = rsi(N, 14)
ema50, ema200 = N.ewm(span=50, adjust=False).mean(), N.ewm(span=200, adjust=False).mean()
F["n_dist_ema50"] = 100*(N/ema50 - 1)
F["n_dist_ema200"] = 100*(N/ema200 - 1)
F["n_ema50_gt_200"] = (ema50 > ema200).astype(int)
F["n_dd_252"] = 100*(N/N.rolling(252, min_periods=60).max() - 1)
F["iv_pct_252"] = pct_rank(F["INDIAVIX"], 252)
F["uv_pct_252"] = pct_rank(F["USVIX"], 252)
line = N.ewm(span=12, adjust=False).mean() - N.ewm(span=26, adjust=False).mean()
F["n_macd_hist"] = line - line.ewm(span=9, adjust=False).mean()
w = N.resample("W-FRI").last()
F["a_weekly"] = (w > w.ewm(span=30, adjust=False).mean()).reindex(F.index, method="ffill").fillna(False).astype(int)
F["a_ema200"] = (F["n_dist_ema200"] > 0).astype(int)
F["a_ema50"] = (F["n_dist_ema50"] > 0).astype(int)
F["a_golden"] = F["n_ema50_gt_200"]
F["a_rsi60"] = (F["n_rsi14"] > 60).astype(int)
F["a_macd"] = (F["n_macd_hist"] > 0).astype(int)
F["a_bothvixlow"] = ((F["uv_pct_252"] < 30) & (F["iv_pct_252"] < 30)).astype(int)
ATOMS = ["a_ema200","a_ema50","a_golden","a_weekly","a_rsi60","a_macd","a_bothvixlow"]
F["bull_count"] = F[ATOMS].sum(axis=1)
low126 = N.rolling(126, min_periods=60).min()
F["dist_6mlow"] = 100*(N/low126 - 1)
# targets
F["ret_1M"] = 100*(N.shift(-21)/N - 1); F["ret_3M"] = 100*(N.shift(-63)/N - 1)
F["fmin_3M"] = 100*(N.rolling(63).min().shift(-63)/N - 1)
F["fmax_3M"] = 100*(N.rolling(63).max().shift(-63)/N - 1)
F["y_up_1M"] = (F["ret_1M"] > 0).astype(float); F["y_up_3M"] = (F["ret_3M"] > 0).astype(float)
F["y_dip5_3M"] = (F["fmin_3M"] < -5).astype(float); F["y_rally5_3M"] = (F["fmax_3M"] > 5).astype(float)
F.to_csv(DATA / "features_daily.csv")

print("[3/5] fitting model + walk-forward calibration ...")
FEATS = ["iv_pct_252","uv_pct_252","n_dd_252","n_dist_ema200","bull_count"]
X = F[FEATS].ffill().fillna(0).replace([np.inf, -np.inf], 0)
EMB = pd.Timedelta(days=100)
tr = F.index <= (F.index[-1] - EMB)
sc = StandardScaler().fit(X.values[tr])
model = {"features": FEATS,
         "scaler_mean": [round(float(v),4) for v in sc.mean_],
         "scaler_scale": [round(float(v),4) for v in sc.scale_]}
for tgt in ["y_up_1M","y_up_3M","y_dip5_3M","y_rally5_3M"]:
    lr = LogisticRegression(C=0.3, max_iter=3000).fit(sc.transform(X.values[tr]), F[tgt].values[tr])
    model[tgt] = {"w":[round(float(v),4) for v in lr.coef_[0]], "b": round(float(lr.intercept_[0]),4)}

def logit(p):
    p = np.clip(p, 1e-4, 1-1e-4); return np.log(p/(1-p))

dates = [t for t in pd.Series(F.index, index=F.index).resample("ME").last().dropna()
         if pd.Timestamp("2020-01-31") <= t <= pd.Timestamp("2026-06-30")]
oos = {t: [] for t in ["y_up_1M","y_up_3M","y_dip5_3M","y_rally5_3M"]}
for t in dates:
    m = F.index <= (t - EMB)
    if m.sum() < 400:
        continue
    s2 = StandardScaler().fit(X.values[m]); i = int(np.where(F.index == t)[0][0])
    for tgt in oos:
        ytr = F.loc[m, tgt].values
        if len(np.unique(ytr)) < 2:
            continue
        lr = LogisticRegression(C=0.3, max_iter=3000).fit(s2.transform(X.values[m]), ytr)
        oos[tgt].append({"p": float(lr.predict_proba(s2.transform(X.values[i:i+1]))[0,1]), "y": float(F[tgt].iloc[i])})

calib = {}
for tgt, rows in oos.items():
    r = pd.DataFrame(rows)
    pl = LogisticRegression(C=1e6).fit(logit(r["p"].values).reshape(-1,1), r["y"].values)
    calib[tgt] = {"platt_a": round(float(pl.coef_[0,0]),4), "platt_b": round(float(pl.intercept_[0]),4),
                  "oos_hit%": round(float(((r["p"]>.5)==(r["y"]>.5)).mean()*100),1),
                  "base_rate%": round(float(r["y"].mean()*100),1), "n": int(len(r))}

r3 = pd.DataFrame(oos["y_up_3M"])
qcut = [round(float(v),4) for v in r3["p"].quantile([.2,.4,.6,.8])]
bins = pd.qcut(r3["p"], 5, duplicates="drop")
qacc = r3.groupby(bins, observed=True).agg(avg_p=("p","mean"), acc=("y", lambda s: 100*(s>0).mean()), n=("y","size"))
quintiles = [{"bucket": i+1, "p_lo": round(float(iv.left),4), "p_hi": round(float(iv.right),4),
              "avg_conf": round(float(row["avg_p"]),3), "accuracy%": round(float(row["acc"]),1), "n": int(row["n"])}
             for i,(iv,row) in enumerate(qacc.iterrows())]

print("[4/5] scenario statistics ...")
def episodes(mask, gap=10):
    m = mask.fillna(False).values; idx = F.index; eps, start, prev = [], None, None
    for i,x in enumerate(m):
        if x and start is None: start = i
        elif x:
            if (idx[i]-idx[prev]).days > gap: eps.append((start,prev)); start = i
        elif start is not None: eps.append((start,prev)); start = None
        prev = i
    if start is not None: eps.append((start,prev))
    return eps

def stats(mask, oos_only=False):
    eps = episodes(mask)
    rows = [F.iloc[a] for a,b in eps]
    if oos_only: rows = [r for r in rows if r.name >= pd.Timestamp("2023-01-01")]
    e = pd.DataFrame(rows)
    if len(e) == 0: return None
    def f(c):
        s = e[c].dropna()
        return {"n": int(len(s)), "med": round(float(s.median()),2), "avg": round(float(s.mean()),2),
                "up%": round(float(100*(s>0).mean()),1)}
    return {"events": len(e), "days": int(sum(b-a+1 for a,b in eps)), "ret1": f("ret_1M"), "ret3": f("ret_3M"),
            "dip3": round(float(e["fmin_3M"].median()),2), "rally3": round(float(e["fmax_3M"].median()),2)}

MASK = {
 "panic_washout": (F["n_dd_252"] < -10) & (F["INDIAVIX"] > 20),
 "both_panic": (F["iv_pct_252"] > 70) & (F["uv_pct_252"] > 70),
 "slow_bleed": (F["n_rsi14"] < 30) & (F["INDIAVIX"] < 17),
 "deep_oversold_fear": (F["n_dist_ema200"] < -5) & (F["n_rsi14"] < 30) & (F["iv_pct_252"] > 50),
 "retest": (F["dist_6mlow"].between(-1,3)) & (F["n_rsi14"] < 40),
 "local_fear": (F["iv_pct_252"] > 50) & (F["uv_pct_252"] < 50),
 "momentum_bull": (F["n_dist_ema200"] > 0) & (F["bull_count"] >= 4),
 "complacency": (F["iv_pct_252"] < 25) & (F["uv_pct_252"] < 30) & (F["n_rsi14"] > 65),
}
scen_period = {k: {"stats_all": stats(m), "stats_2023plus": stats(m, True)} for k, m in MASK.items()}

last = F.iloc[-1]
live_inputs = {"nifty": round(float(last["NIFTY"]),0), "india_vix": round(float(last["INDIAVIX"]),2),
               "india_vix_pct": round(float(last["iv_pct_252"]),1), "us_vix": round(float(last["USVIX"]),2),
               "us_vix_pct": round(float(last["uv_pct_252"]),1), "rsi14": round(float(last["n_rsi14"]),1),
               "dist200": round(float(last["n_dist_ema200"]),2), "dd252": round(float(last["n_dd_252"]),2),
               "dist6mlow": round(float(last["dist_6mlow"]),2), "bull_count": int(last["bull_count"]),
               "atoms": {a: int(last[a]) for a in ATOMS}}

# FIX (MED finding): live probabilities + matched scenarios ko bhi app_data me store karo.
# Pehle refresh ke baad ye values kahin persist nahi hoti thin (sirf browser me compute hoti thin).
_xi = X.values[-1:]
_xs = (_xi - sc.mean_) / sc.scale_
live_probs_raw, live_probs_cal = {}, {}
for _tgt in ["y_up_1M","y_up_3M","y_dip5_3M","y_rally5_3M"]:
    _z = float(np.dot(model[_tgt]["w"], _xs[0]) + model[_tgt]["b"])
    live_probs_raw[_tgt] = round(float(1/(1+np.exp(-_z))), 4)
    _a, _b = calib[_tgt]["platt_a"], calib[_tgt]["platt_b"]
    live_probs_cal[_tgt] = round(float(1/(1+np.exp(-(_a*_z + _b)))), 4)
matched_live = [k for k, m in MASK.items() if bool(m.iloc[-1])]

PRESETS = ["2018-10-26","2020-03-23","2021-10-19","2022-06-16","2024-11-13","2025-02-28","2026-03-30"]
presets = []
for ds in PRESETS:
    i = min(max(int(F.index.searchsorted(pd.Timestamp(ds))), 0), len(F)-1); row = F.iloc[i]
    presets.append({"date": str(F.index[i].date()), "label": F.index[i].strftime("%b %Y"),
        "inputs": {"nifty": round(float(row["NIFTY"]),0), "india_vix": round(float(row["INDIAVIX"]),2),
                   "india_vix_pct": round(float(row["iv_pct_252"]),1), "us_vix": round(float(row["USVIX"]),2),
                   "us_vix_pct": round(float(row["uv_pct_252"]),1), "rsi14": round(float(row["n_rsi14"]),1),
                   "dist200": round(float(row["n_dist_ema200"]),2), "dd252": round(float(row["n_dd_252"]),2),
                   "dist6mlow": round(float(row["dist_6mlow"]),2), "bull_count": int(row["bull_count"]),
                   "atoms": {a: int(row[a]) for a in ATOMS}},
        "actual": {"ret_1M": None if pd.isna(row["ret_1M"]) else round(float(row["ret_1M"]),2),
                   "ret_3M": None if pd.isna(row["ret_3M"]) else round(float(row["ret_3M"]),2),
                   "dip_3M": None if pd.isna(row["fmin_3M"]) else round(float(row["fmin_3M"]),2),
                   "rally_3M": None if pd.isna(row["fmax_3M"]) else round(float(row["fmax_3M"]),2)}})

prev = {}
pfile = DATA / "app_data.json"
if pfile.exists():
    try:
        prev = json.load(open(pfile))
    except Exception:
        prev = {}

APP = {
 "meta": {"title": "NIFTY Market Scenario Predictor", "as_of": str(F.index[-1].date()),
          "data_start": str(F.index[0].date()), "data_end": str(F.index[-1].date()),
          "n_days": int(len(F)), "years": round(len(F)/252,1)},
 "model": model, "calibration": calib, "quintiles": quintiles, "quintile_cutoffs": qcut,
 "scenarios": scen_period, "scenario_order": ["panic_washout","both_panic","slow_bleed","deep_oversold_fear",
                                              "retest","local_fear","momentum_bull","complacency"],
 "live": {"date": str(F.index[-1].date()), "inputs": live_inputs,
          "probs_raw": live_probs_raw, "probs_cal": live_probs_cal, "scenarios_matched": matched_live},
 "accuracy": prev.get("accuracy", {"vix_direction_1M": 61.7, "vix_direction_2M": 62.9, "vix_baseline": 44.7, "nifty_dir_1M": 62.8, "nifty_dir_3M": 62.8, "nifty_base_1M": 64.1, "nifty_base_3M": 66.7, "dip_auc": 0.57, "rally_auc": 0.607, "dir3M_auc": 0.676, "sweep_win": 69.4, "vixgt20_win": 73.3, "dd10_win": 75.0, "combos_searched": 99762, "model_versions": 12}),
 "presets": presets,
 "sweeps": prev.get("sweeps", {}),
}
from collections import OrderedDict
SCEN_TEXT = prev.get("scenarios", {})
# keep human-written text (name/rule/meaning/action) if present, else minimal defaults
DEFAULTS = {
 "panic_washout": ("Panic Washout (drawdown + India VIX > 20)","(52w-high se -10% se zyada neeche) AND (India VIX > 20)","Capitulation ho chuki hai (VIX washout). History me best 3M payoff yahan hota hai.","Tranche deploy — highest-payoff bucket (par 3M me 5%+ dip prob ~33%)."),
 "both_panic": ("Both-Market Panic (India + US VIX > 70th pct)","(India VIX %ile > 70) AND (US VIX %ile > 70)","Dono markets panic me — data me ye SABSE KHARAB setup hai (3M avg negative).","Naya capital nahi — wait karo."),
 "slow_bleed": ("Slow Bleed (oversold par VIX shant < 17)","(RSI14 < 30) AND (India VIX < 17)","Washout nahi hua; 1M me bounce, 3M me aksar aur neeche.","Chhota starter hi; bada bet VIX 20+ washout par."),
 "deep_oversold_fear": ("Deep Oversold + Fear (below 200EMA, RSI<30, VIX %ile>50)","(200EMA se -5% neeche) AND (RSI14 < 30) AND (VIX %ile > 50)","Bullish extreme — 1M me 73% upar.","Tranche-1/2; stop 200EMA se 5% neeche weekly close."),
 "retest": ("6M-Low Retest (low ke 3% andar, RSI<40)","(6-mahine low ke 3% andar) AND (RSI14 < 40)","Purana low test — historically 3M median +7% (77% upar).","Tranche-2 ka best zone; stop 6M-low break."),
 "local_fear": ("Local Fear (India VIX %ile>50, US calm)","(India VIX %ile > 50) AND (US VIX %ile < 50)","India-specific fear historically buyable (3M avg +2.7%).","Accumulation zone."),
 "momentum_bull": ("Momentum Bull (above 200EMA + bull-count >= 4)","(200EMA ke upar) AND (bull-count >= 4)","Deep-search me highest hit-rate family.","Buy-the-dip; trend-following ON."),
 "complacency": ("Complacency (dono VIX calm + overbought)","(India VIX %ile<25 AND US VIX %ile<30) AND (RSI14 > 65)","1M upar, 3M hangover; low VIX = sasti hedging.","Ride + trailing stop."),
}
for k, (nm, rule, mean, act) in DEFAULTS.items():
    if k in APP["scenarios"]:
        src = SCEN_TEXT.get(k, {})
        APP["scenarios"][k].update({"key": k, "name": src.get("name", nm), "rule": src.get("rule", rule),
                                    "meaning": src.get("meaning", mean), "action": src.get("action", act)})

print("[5/5] writing data/app_data.json + injecting into index.html ...")
json.dump(APP, open(DATA / "app_data.json", "w"), indent=2)
# FIX: live prediction ko alag file me bhi save karo (pehle sirf index.html me chala jata tha,
# python/CLI/future runs ke liye kahin store nahi hota tha)
try:
    json.dump({"as_of": APP["meta"]["as_of"], "inputs": APP["live"]["inputs"],
               "probs_raw": APP["live"].get("probs_raw", {}), "probs_cal": APP["live"].get("probs_cal", {}),
               "scenarios_matched": APP["live"].get("scenarios_matched", []),
               "quintile": next((q for q in APP.get("quintiles", [])
                                   if q["p_lo"] <= APP["live"].get("probs_raw", {}).get("y_up_3M", 0) <= q["p_hi"]), None)},
              open(DATA / "live_forecast.json", "w"), indent=2)
    print("   data/live_forecast.json written")
except Exception as _e:
    print("   live_forecast.json skip:", _e)
idx = ROOT / "index.html"
if idx.exists():
    h = idx.read_text()
    h = re.sub(r'(<script id="APP_DATA" type="application/json">).*?(</script>)',
               lambda m: m.group(1) + json.dumps(APP) + m.group(2), h, flags=re.S)
    idx.write_text(h)
    print("   index.html updated")
print("done. Open index.html in a browser.")
