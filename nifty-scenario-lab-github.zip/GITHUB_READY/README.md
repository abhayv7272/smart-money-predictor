# 📈 NIFTY Market Scenario Predictor

**Ek research-backed market scenario engine** — India VIX + US VIX + drawdown + 200-EMA distance (5 features) se
NIFTY ke agle 1–3 mahine ka **scenario + probability + expected levels** nikaalta hai. Zero backend, single HTML file.

> 10 saal ka data · 99,762 combinations ka exhaustive research · walk-forward validated · **honest accuracy: 62–67%**

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](#license)
![Python](https://img.shields.io/badge/python-3.9%2B-blue)
![Data](https://img.shields.io/badge/data-2016-12-01%20→%202026-10-01-green)

---

## ⚡ Quick start

```bash
# sirf dekhna hai? index.html browser me kholo — bas.
git clone <your-repo-url> && cd nifty-scenario-lab
open index.html          # macOS  (Windows: start index.html)

# data refresh karna hai (naya close aane par):
pip install -r python/requirements.txt
python python/update_dashboard.py     # index.html khud update ho jata hai
```

GitHub Pages par live karne ke liye: **Settings → Pages → Branch: main / root** → `https://<user>.github.io/nifty-scenario-lab/`

---

## 🔮 Kya karta hai

| Output | Kaise |
|---|---|
| **P(NIFTY up, 1M / 3M)** | Logistic model (5 features) + Platt calibration |
| **P(5%+ dip / 5%+ rally, 3M)** | Alag models, same features |
| **Matched scenarios** | 8 historical states (panic washout, slow bleed, retest, momentum bull…) |
| **Expected levels** | Scenario medians + model bucket ka 50-50 blend |
| **Confidence bucket (Q1–Q5)** | Us bucket ki historical accuracy (Q5 = 93.8%) |
| **Action plan** | Tranche sizing, stop, invalidation — scenario ke hisaab se |

Aaj ka live state (last data point **2026-10-01**): NIFTY **22,422**, India VIX **14.46** (72.5th pct),
US VIX **16.34** (33.5th pct), RSI-14 **22.6**, 200-EMA se **-7.2%**, 52w-high se **-14.8%**, bull-count **0/7**.

---

## 🎯 Accuracy (walk-forward, out-of-sample 2020–2026, n=78 mahine)

| Prediction | Accuracy | Baseline | Verdict |
|---|---|---|---|
| **India VIX direction (1M)** | **61.7%** | 44.7% | ✅ +17.0 pp |
| India VIX direction (2M) | 62.9% | 44.7% | ✅ |
| NIFTY direction (1M) | 62.8% | 64.1% | ⚠️ baseline ke barabar/kam |
| NIFTY direction (3M) | 62.8% | 66.7% | ⚠️ edge ranking (AUC 0.676) me, hit-rate me nahi |
| Dip >5% risk (3M) | 64.1% | 65.4% | ⚠️ AUC 0.57 (ranking skill) |
| Sweep-low + VIX>50 system | 75.0% win | 65.3% (plain sweep) | ✅ trade-level, n≈28 |
| India VIX > 20 buy system | 73.3% win | — | ✅ avg +5.17%/trade |
| Drawdown > 10% buy system | 75.0% win | — | ✅ avg +5.58%/trade |

**Confidence buckets (raw model prob → actual 3M accuracy):**

| Bucket | Actual accuracy | n |
|---|---|---|
| Q1 | **56.2%** | 16 |
| Q2 | **46.7%** | 15 |
| Q3 | **62.5%** | 16 |
| Q4 | **73.3%** | 15 |
| Q5 | **93.8%** | 16 |

> **Sabse important sabaq:** model sabse confident hone par **93.8%** accurate tha, par medium-confidence zone me **46%** (coin flip).
> Isliye position size confidence ke saath scale karo. Poori imaandari se: **90%+ accuracy ka koi legitimate dava is domain me nahi hai.**

---

## 📚 8 Scenarios (episode-level, 2017–2026)

| Scenario | Rule | Episodes | 1M median | 3M median | 3M up% |
|---|---|---|---|---|---|
| Panic Washout (drawdown + India VIX > 20) | `(NIFTY 52w-high se -10% se zyada neeche) AND (India VIX > 20)` | 17 | +3.4% | +6.0% | 88% |
| Both-Market Panic (India + US VIX > 70th pct) | `(India VIX %ile > 70) AND (US VIX %ile > 70)` | 49 | +0.4% | -0.2% | 50% |
| Slow Bleed (oversold par VIX shant < 17) | `(RSI14 < 30) AND (India VIX < 17)` | 11 | +1.5% | -1.7% | 44% |
| Deep Oversold + Fear (below 200EMA, RSI<30, VIX %ile>50) | `(200EMA se -5% se zyada neeche) AND (RSI14 < 30) AND (India VIX %ile > 50)` | 7 | +3.5% | +5.4% | 83% |
| 6M-Low Retest (low ke 3% andar, RSI<40) | `(NIFTY 6-mahine low ke 3% andar) AND (RSI14 < 40)` | 43 | +1.7% | +6.3% | 71% |
| Local Fear (India VIX %ile>50, US calm) | `(India VIX %ile > 50) AND (US VIX %ile < 50)` | 76 | +1.1% | +3.0% | 70% |
| Momentum Bull (above 200EMA + bull-count >= 4) | `200EMA ke upar AND bull-count >= 4 (strength atoms)` | 78 | +1.6% | +5.3% | 74% |
| Complacency (dono VIX calm + overbought) | `(India VIX %ile<25 AND US VIX %ile<30) AND (RSI14 > 65)` | 41 | +2.2% | +5.0% | 80% |

*(Episode-level = ek hi crash ke 60 din alag-alag events nahi gine jate — isliye ye numbers honest hain.)*

---

## 🧪 Method

**Features (5):** `iv_pct_252` (India VIX ka 252-din percentile), `uv_pct_252` (US VIX percentile),
`n_dd_252` (52-week high se drawdown), `n_dist_ema200` (200-EMA se % doori), `bull_count` (7 strength atoms ka sum).

**Formula:** `z = Σ wᵢ·(xᵢ−μᵢ)/σᵢ + b` → `p = σ(z)` → `p_cal = σ(a·logit(p)+b)`

**Protocol (no cheating):**
1. Har mahine model dobara train — sirf us din available data se.
2. **100-din embargo** (3M label future ka hota hai, isliye training window se 100 din pehle cut).
3. Coefficients is page me embedded hain — koi backend nahi, offline chalta hai.

**Research trail (isse pata chalta hai ye model kyun *simple* hai):**
- **99,762 combinations** (67 atomic conditions ke 1/2/3/4-way AND combos) search kiye — IS (2017-22) par chuna, OOS (2023-26) par verify.
- IS ka **top decile (86.1% hit) → OOS 65.8%** (baseline 66.4% se bhi kam). Top-2000 selected combos ka OOS mean **66.3%** vs random **66.0%** → **selection edge ≈ 0**.
- Random combos ka **p90 = 85.7%, p99 = 100%** → chhote sample ke "100% accuracy" combos luck hote hain.
- Liquidity sweeps (swing low/high stop-hunts, 73/69 episodes; double sweeps 23): alone koi edge nahi; **sweep + VIX%ile>50** system = 75.0% win (n=28 trades), CAGR 6.5%, MaxDD −15.2%, exposure 24% — sample chhota hai, isliye "tail-risk filter" maano.
- India VIX mean-reversion: VIX pct > 90 par 3M me VIX median **−23%** (86% baar girta hai).
- 12 model versions (sweeps, 30-feature, 66-atom ML, auto-select) — **4-feature core ne sabko beat kiya**; final me sirf `bull_count` add hua.

---

## 📁 Structure

```
nifty-scenario-lab/
├── index.html                  # ⭐ self-contained app (GitHub Pages ready)
├── data/
│   ├── app_data.json          # model params + scenario stats + presets
│   ├── scenario_stats.csv     # 8 scenarios ke episode-level results
│   ├── accuracy_scorecard.csv # honest accuracy table
│   └── confidence_buckets.csv # Q1–Q5 accuracy
├── python/
│   ├── update_dashboard.py    # ek command me poora refresh
│   └── requirements.txt
├── web/index.template.html    # app template (rebuild ke liye)
├── LICENSE
├── DESCRIPTION.md / DESCRIPTION.txt   # poori Hinglish description
├── FIX_LOG.md                          # bugs + fixes ka log
└── .nojekyll
```

---

## ⚠️ Limitations (padhna zaroori hai)

- **1M direction me model baseline se kamzor** hai (62.8% vs 64.1%) — short-term unpredictable hai.
- **3M hit-rate ka koi edge nahi**; edge **ranking (AUC 0.676)**, confidence buckets aur risk-mapping me hai.
- **Events model nahi hote:** war, election, policy shock, FII ban — sirf tail probability me dikhte hain.
- Sample chhota hai (9.7 saal = 1 bada crash). Deep-oversold states sirf 7–11 baar aaye.
- Regime shift: 2017-22 aur 2023-26 ka behaviour alag hai; isliye scenario stats dono windows me diye hain.

## ⚖️ Disclaimer

**Educational research only. SEBI-registered investment advice nahi.**
Ye historical data par backtested research hai — future returns guarantee nahi. Options/F&O me leverage ke saath
is model ka use capital-destroying ho sakta hai. Apna risk khud manage karo, ya apne registered advisor se baat karo.

## 📜 License

MIT — use karo, fork karo, improve karo. Credit appreciated. 🙏
