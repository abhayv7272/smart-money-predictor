#!/usr/bin/env python3
"""
NIFTY Market Scenario Predictor — standalone CLI
================================================
Ek hi file, koi dependency nahi (sirf python3). Model weights + calibration + scenario
statistics is file me embedded hain.

Usage
-----
  # 1) Embedded snapshot (project ke last data point) par prediction:
  python predict_nifty.py

  # 2) Apne numbers daal ke:
  python predict_nifty.py --nifty 22422 --vix 14.46 --vix-pct 72.5 --us-vix-pct 36.7 \
      --rsi 22.6 --dist200 -7.18 --dd252 -14.84 --dist6mlow 0 --bull 0

  # 3) Yahoo Finance se latest data khud laake (iske liye: pip install yfinance pandas):
  python predict_nifty.py --fetch

Output: calibrated probabilities, confidence bucket, matched scenarios, expected levels, action plan.
Educational research only — investment advice nahi.
"""
from __future__ import annotations
import argparse, json, math, sys

APP = json.loads(r"""{"meta": {"title": "NIFTY Market Scenario Predictor", "as_of": "2026-10-01", "data_start": "2016-12-01", "data_end": "2026-10-01", "n_days": 2427, "years": 9.6}, "model": {"features": ["iv_pct_252", "uv_pct_252", "n_dd_252", "n_dist_ema200", "bull_count"], "scaler_mean": [46.8692, 47.0261, -4.7703, 4.6124, 4.2202], "scaler_scale": [31.9839, 32.1341, 5.3208, 6.3729, 1.887], "y_up_1M": {"w": [-0.0024, -0.1682, -0.4801, 0.0154, 0.1513], "b": 0.6183}, "y_up_3M": {"w": [-0.0884, -0.6825, -1.603, 0.2998, 0.1511], "b": 1.0126}, "y_dip5_3M": {"w": [-0.085, 0.5108, 0.4372, 0.109, -0.1934], "b": -0.916}, "y_rally5_3M": {"w": [-0.1751, -0.2995, -1.2695, 0.4862, -0.0089], "b": 0.4528}}, "calibration": {"y_up_1M": {"platt_a": 0.1987, "platt_b": 0.4114, "oos_hit%": 62.8, "oos_auc": 0.519, "base_rate%": 64.1, "n": 78}, "y_up_3M": {"platt_a": 0.5285, "platt_b": -0.1386, "oos_hit%": 62.8, "oos_auc": 0.676, "base_rate%": 66.7, "n": 78}, "y_dip5_3M": {"platt_a": -0.0846, "platt_b": -0.7567, "oos_hit%": 64.1, "oos_auc": 0.57, "base_rate%": 34.6, "n": 78}, "y_rally5_3M": {"platt_a": 0.4073, "platt_b": 0.1381, "oos_hit%": 56.4, "oos_auc": 0.607, "base_rate%": 62.8, "n": 78}}, "quintiles": [{"bucket": 1, "p_lo": 0.359, "p_hi": 0.652, "avg_conf": 0.506, "accuracy%": 56.2, "n": 16}, {"bucket": 2, "p_lo": 0.652, "p_hi": 0.78, "avg_conf": 0.734, "accuracy%": 46.7, "n": 15}, {"bucket": 3, "p_lo": 0.78, "p_hi": 0.87, "avg_conf": 0.825, "accuracy%": 62.5, "n": 16}, {"bucket": 4, "p_lo": 0.87, "p_hi": 0.932, "avg_conf": 0.904, "accuracy%": 73.3, "n": 15}, {"bucket": 5, "p_lo": 0.932, "p_hi": 1.0, "avg_conf": 0.967, "accuracy%": 93.8, "n": 16}], "quintile_cutoffs": [0.6522, 0.7804, 0.8703, 0.9315], "scenarios": {"panic_washout": {"key": "panic_washout", "name": "Panic Washout (drawdown + India VIX > 20)", "rule": "(NIFTY 52w-high se -10% se zyada neeche) AND (India VIX > 20)", "meaning": "Capitulation ho chuki hai (VIX ne washout dikhaya). History me best 3M payoff yahan hota hai.", "action": "Tranche deploy — historically highest-payoff bucket (par 3M me 5%+ dip ki probability bhi ~33% hai).", "stats_all": {"events": 17, "days": 167, "ret1": {"n": 17, "med": 3.4, "avg": 2.49, "up%": 82.4}, "ret3": {"n": 17, "med": 5.95, "avg": 6.66, "up%": 88.2}, "dip3": -2.92, "rally3": 7.83}, "stats_2023+": {"events": 3, "days": 167, "ret1": {"n": 3, "med": 5.09, "avg": 6.64, "up%": 100.0}, "ret3": {"n": 3, "med": 4.43, "avg": 7.09, "up%": 100.0}, "dip3": -2.92, "rally3": 6.84}}, "both_panic": {"key": "both_panic", "name": "Both-Market Panic (India + US VIX > 70th pct)", "rule": "(India VIX %ile > 70) AND (US VIX %ile > 70)", "meaning": "Dono markets panic me. Contrarian lagta hai par data me ye SABSE KHARAB setup hai (3M avg negative).", "action": "Naya capital nahi — wait. Pehle se invested ho to hedging / position-size check karo.", "stats_all": {"events": 49, "days": 402, "ret1": {"n": 49, "med": 0.39, "avg": -0.98, "up%": 53.1}, "ret3": {"n": 48, "med": -0.19, "avg": -0.37, "up%": 50.0}, "dip3": -4.36, "rally3": 5.74}, "stats_2023+": {"events": 20, "days": 402, "ret1": {"n": 20, "med": 0.52, "avg": -0.49, "up%": 55.0}, "ret3": {"n": 19, "med": -1.01, "avg": -0.13, "up%": 42.1}, "dip3": -4.83, "rally3": 4.18}}, "slow_bleed": {"key": "slow_bleed", "name": "Slow Bleed (oversold par VIX shant < 17)", "rule": "(RSI14 < 30) AND (India VIX < 17)", "meaning": "Washout nahi hua — market dheere-dheere gir raha hai. 1M me bounce aata hai, 3M me aksar aur neeche.", "action": "Chhota starter position hi lo; bada bet VIX 20+ washout par rakho.", "stats_all": {"events": 11, "days": 48, "ret1": {"n": 9, "med": 1.5, "avg": 1.92, "up%": 88.9}, "ret3": {"n": 9, "med": -1.73, "avg": 2.47, "up%": 44.4}, "dip3": -2.99, "rally3": 6.07}, "stats_2023+": {"events": 9, "days": 48, "ret1": {"n": 7, "med": 1.5, "avg": 2.47, "up%": 100.0}, "ret3": {"n": 7, "med": -2.13, "avg": 0.79, "up%": 28.6}, "dip3": -2.99, "rally3": 5.25}}, "deep_oversold_fear": {"key": "deep_oversold_fear", "name": "Deep Oversold + Fear (below 200EMA, RSI<30, VIX %ile>50)", "rule": "(200EMA se -5% se zyada neeche) AND (RSI14 < 30) AND (India VIX %ile > 50)", "meaning": "Bullish extreme: 1M me 73% upar. Par 'slow bleed' version se dhyan — VIX<17 ho to thesis weak.", "action": "Tranche-1/2 yahan historically best (3M median +6.4%), stop 200EMA se 5% aur neeche weekly close.", "stats_all": {"events": 7, "days": 27, "ret1": {"n": 6, "med": 3.49, "avg": 0.59, "up%": 83.3}, "ret3": {"n": 6, "med": 5.4, "avg": 4.52, "up%": 83.3}, "dip3": -3.09, "rally3": 8.01}, "stats_2023+": {"events": 4, "days": 27, "ret1": {"n": 3, "med": 5.09, "avg": 4.55, "up%": 100.0}, "ret3": {"n": 3, "med": 4.43, "avg": 3.77, "up%": 100.0}, "dip3": -2.92, "rally3": 6.84}}, "retest": {"key": "retest", "name": "6M-Low Retest (low ke 3% andar, RSI<40)", "rule": "(NIFTY 6-mahine low ke 3% andar) AND (RSI14 < 40)", "meaning": "Purana low test ho raha hai. Historically 3M median +7% (77% upar).", "action": "Tranche-2 yahan historically best hai; stop 6M-low ke neeche weekly close par.", "stats_all": {"events": 43, "days": 115, "ret1": {"n": 42, "med": 1.73, "avg": 2.01, "up%": 71.4}, "ret3": {"n": 42, "med": 6.28, "avg": 5.73, "up%": 71.4}, "dip3": -2.91, "rally3": 8.24}, "stats_2023+": {"events": 24, "days": 115, "ret1": {"n": 23, "med": 1.36, "avg": 1.58, "up%": 60.9}, "ret3": {"n": 23, "med": 5.38, "avg": 4.57, "up%": 69.6}, "dip3": -3.69, "rally3": 7.26}}, "local_fear": {"key": "local_fear", "name": "Local Fear (India VIX %ile>50, US calm)", "rule": "(India VIX %ile > 50) AND (US VIX %ile < 50)", "meaning": "Fear sirf India me hai (FII / event related). 3M me 72% upar, avg +2.6%.", "action": "Accumulation zone — India-specific fear historically buyable hota hai.", "stats_all": {"events": 76, "days": 362, "ret1": {"n": 73, "med": 1.14, "avg": 1.16, "up%": 69.9}, "ret3": {"n": 70, "med": 2.95, "avg": 2.2, "up%": 70.0}, "dip3": -3.26, "rally3": 5.63}, "stats_2023+": {"events": 29, "days": 362, "ret1": {"n": 26, "med": 0.84, "avg": 1.17, "up%": 73.1}, "ret3": {"n": 23, "med": 2.25, "avg": 1.98, "up%": 60.9}, "dip3": -3.62, "rally3": 4.45}}, "momentum_bull": {"key": "momentum_bull", "name": "Momentum Bull (above 200EMA + bull-count >= 4)", "rule": "200EMA ke upar AND bull-count >= 4 (strength atoms)", "meaning": "Deep-search me highest hit-rate family (strength + calm VIX).", "action": "Buy-the-dip on minor pullbacks; trend-following kar sakte ho.", "stats_all": {"events": 78, "days": 1653, "ret1": {"n": 78, "med": 1.59, "avg": 0.44, "up%": 65.4}, "ret3": {"n": 76, "med": 5.27, "avg": 2.87, "up%": 73.7}, "dip3": -1.81, "rally3": 7.67}, "stats_2023+": {"events": 27, "days": 1653, "ret1": {"n": 27, "med": 1.39, "avg": 0.9, "up%": 55.6}, "ret3": {"n": 25, "med": 5.87, "avg": 4.6, "up%": 76.0}, "dip3": -3.98, "rally3": 6.42}}, "complacency": {"key": "complacency", "name": "Complacency (dono VIX calm + overbought)", "rule": "(India VIX %ile<25 AND US VIX %ile<30) AND (RSI14 > 65)", "meaning": "1M me aksar upar, par 3M me hangover — fear premium khatam, hedging sasta.", "action": "Ride karo par trailing stop; low VIX ko hedging ka mauka samjho.", "stats_all": {"events": 41, "days": 150, "ret1": {"n": 41, "med": 2.17, "avg": 2.16, "up%": 75.6}, "ret3": {"n": 41, "med": 5.03, "avg": 3.81, "up%": 80.5}, "dip3": -1.07, "rally3": 7.08}, "stats_2023+": {"events": 14, "days": 150, "ret1": {"n": 14, "med": 2.56, "avg": 2.13, "up%": 78.6}, "ret3": {"n": 14, "med": 5.31, "avg": 4.66, "up%": 85.7}, "dip3": -0.93, "rally3": 6.96}}}, "scenario_order": ["panic_washout", "both_panic", "slow_bleed", "deep_oversold_fear", "retest", "local_fear", "momentum_bull", "complacency"], "live": {"date": "2026-10-01", "inputs": {"nifty": 22422.0, "india_vix": 14.46, "india_vix_pct": 72.5, "us_vix": 16.34, "us_vix_pct": 33.5, "rsi14": 22.6, "dist200": -7.18, "dd252": -14.84, "dist6mlow": 0.0, "bull_count": 0, "atoms": {"a_ema200": 0, "a_ema50": 0, "a_golden": 0, "a_weekly": 0, "a_rsi60": 0, "a_macd": 0, "a_bothvixlow": 0}}, "probs_raw": {"y_up_1M": 0.7736, "y_up_3M": 0.9668, "y_dip5_3M": 0.1423, "y_rally5_3M": 0.8766}, "probs_cal": {"y_up_1M": 0.6583, "y_up_3M": 0.8379, "y_dip5_3M": 0.3533, "y_rally5_3M": 0.7184}, "scenarios_matched": ["slow_bleed", "deep_oversold_fear", "retest", "local_fear"]}, "accuracy": {"vix_direction_1M": 61.7, "vix_direction_2M": 62.9, "vix_baseline": 44.7, "nifty_dir_1M": 62.8, "nifty_dir_3M": 62.8, "nifty_base_1M": 64.1, "nifty_base_3M": 66.7, "dip_auc": 0.57, "rally_auc": 0.607, "dir3M_auc": 0.676, "dir1M_auc": 0.519, "sweep_win": 75.0, "vixgt20_win": 73.3, "dd10_win": 75.0, "combos_searched": 99762, "model_versions": 12, "source": "out/accuracy_final.json (run 2026-10-01)", "vix_direction_3M": 59.8, "dip_hit_3M": 64.1, "rally_hit_3M": 56.4, "sweep_win_plain": 65.3, "below200_win": 71.4, "atoms_screened": 67, "survivors": 3501, "brier_cal_honest": {"up_1M": 0.2585, "up_3M": 0.2518, "dip5_3M": 0.2272, "rally5_3M": 0.3232}, "brier_base_honest": {"up_1M": 0.2461, "up_3M": 0.2461, "dip5_3M": 0.2256, "rally5_3M": 0.2461}, "calibration_note": "Platt calibration pehle 60% OOS par fit, aakhri 40% par evaluate. Hold-out par calibrated Brier base-rate se sirf thoda better/same hai — model ki asli value ranking (AUC) aur high-confidence bucket me hai.", "oos_window": "2020-01-01 -> 2026-06-30 (walk-forward, 100-din embargo)"}, "presets": [{"date": "2018-10-26", "label": "Oct 2018 (low)", "inputs": {"nifty": 10030.0, "india_vix": 19.23, "india_vix_pct": 96.4, "us_vix": 24.22, "us_vix_pct": 96.4, "rsi14": 30.2, "dist200": -6.41, "dd252": -14.55, "dist6mlow": 0.0, "bull_count": 1, "atoms": {"a_ema200": 0, "a_ema50": 0, "a_golden": 1, "a_weekly": 0, "a_rsi60": 0, "a_macd": 0, "a_bothvixlow": 0}}, "actual": {"ret_1M": 6.97, "ret_3M": 6.2, "dip_3M": 1.68, "rally_3M": 9.34}}, {"date": "2020-03-23", "label": "Mar 2020 (low)", "inputs": {"nifty": 7610.0, "india_vix": 71.99, "india_vix_pct": 99.6, "us_vix": 66.04, "us_vix_pct": 98.0, "rsi14": 19.0, "dist200": -33.49, "dd252": -38.44, "dist6mlow": 0.0, "bull_count": 0, "atoms": {"a_ema200": 0, "a_ema50": 0, "a_golden": 0, "a_weekly": 0, "a_rsi60": 0, "a_macd": 0, "a_bothvixlow": 0}}, "actual": {"ret_1M": 21.97, "ret_3M": 36.43, "dip_3M": 2.51, "rally_3M": 37.59}}, {"date": "2021-10-19", "label": "Oct 2021 (high)", "inputs": {"nifty": 18419.0, "india_vix": 17.38, "india_vix_pct": 35.9, "us_vix": 16.31, "us_vix_pct": 8.4, "rsi14": 74.6, "dist200": 17.98, "dd252": -0.32, "dist6mlow": 28.83, "bull_count": 6, "atoms": {"a_ema200": 1, "a_ema50": 1, "a_golden": 1, "a_weekly": 1, "a_rsi60": 1, "a_macd": 1, "a_bothvixlow": 0}}, "actual": {"ret_1M": -3.55, "ret_3M": -1.66, "dip_3M": -9.8, "rally_3M": -0.6}}, {"date": "2022-06-16", "label": "Jun 2022 (low)", "inputs": {"nifty": 15361.0, "india_vix": 22.87, "india_vix_pct": 87.6, "us_vix": 29.62, "us_vix_pct": 87.3, "rsi14": 29.3, "dist200": -7.95, "dd252": -16.87, "dist6mlow": 0.0, "bull_count": 0, "atoms": {"a_ema200": 0, "a_ema50": 0, "a_golden": 0, "a_weekly": 0, "a_rsi60": 0, "a_macd": 0, "a_bothvixlow": 0}}, "actual": {"ret_1M": 4.48, "ret_3M": 14.13, "dip_3M": -0.44, "rally_3M": 17.64}}, {"date": "2024-11-13", "label": "Nov 2024 (low)", "inputs": {"nifty": 23559.0, "india_vix": 15.44, "india_vix_pct": 77.7, "us_vix": 14.71, "us_vix_pct": 57.8, "rsi14": 30.0, "dist200": 0.12, "dd252": -10.14, "dist6mlow": 7.65, "bull_count": 3, "atoms": {"a_ema200": 1, "a_ema50": 0, "a_golden": 1, "a_weekly": 1, "a_rsi60": 0, "a_macd": 0, "a_bothvixlow": 0}}, "actual": {"ret_1M": 4.71, "ret_3M": -2.18, "dip_3M": -3.1, "rally_3M": 5.13}}, {"date": "2025-02-28", "label": "Feb 2025 (low)", "inputs": {"nifty": 22125.0, "india_vix": 13.91, "india_vix_pct": 39.8, "us_vix": 21.13, "us_vix_pct": 94.4, "rsi14": 22.4, "dist200": -5.9, "dd252": -15.61, "dist6mlow": 0.0, "bull_count": 0, "atoms": {"a_ema200": 0, "a_ema50": 0, "a_golden": 0, "a_weekly": 0, "a_rsi60": 0, "a_macd": 0, "a_bothvixlow": 0}}, "actual": {"ret_1M": 5.46, "ret_3M": 11.87, "dip_3M": -0.19, "rally_3M": 13.28}}, {"date": "2026-03-30", "label": "Mar 2026 (low)", "inputs": {"nifty": 22331.0, "india_vix": 27.89, "india_vix_pct": 100.0, "us_vix": 31.05, "us_vix_pct": 97.2, "rsi14": 31.9, "dist200": -10.52, "dd252": -15.18, "dist6mlow": 0.0, "bull_count": 0, "atoms": {"a_ema200": 0, "a_ema50": 0, "a_golden": 0, "a_weekly": 0, "a_rsi60": 0, "a_macd": 0, "a_bothvixlow": 0}}, "actual": {"ret_1M": 8.01, "ret_3M": 8.68, "dip_3M": 1.56, "rally_3M": 10.05}}], "sweeps": {"last_low_sweep_days": 26, "liq_above_pct": 8.96}}""")

# ------------------------------------------------------------------ model
def _sig(z):  return 1.0 / (1.0 + math.exp(-max(-35.0, min(35.0, z))))
def _logit(p):
    p = min(max(p, 1e-4), 1 - 1e-4)
    return math.log(p / (1 - p))

def predict_probs(inp):
    """inp: dict with ivixp, uvixp, dd252, dist200, bull -> raw + calibrated probs."""
    M = APP["model"]
    x = [inp["ivixp"], inp["uvixp"], inp["dd252"], inp["dist200"], inp["bull"]]
    zs = [(x[i] - M["scaler_mean"][i]) / M["scaler_scale"][i] for i in range(5)]
    out = {}
    for k in ["y_up_1M", "y_up_3M", "y_dip5_3M", "y_rally5_3M"]:
        z = sum(w * zs[i] for i, w in enumerate(M[k]["w"])) + M[k]["b"]
        raw = _sig(z)
        c = APP["calibration"][k]
        out[k] = {"raw": raw, "cal": _sig(c["platt_a"] * _logit(raw) + c["platt_b"])}
    return out

# ------------------------------------------------------------------ scenarios
def match_scenarios(inp):
    hit = {}
    hit["panic_washout"]      = inp["dd252"] <= -10 and inp["ivix_abs"] > 20
    hit["both_panic"]         = inp["ivixp"] > 70 and inp["uvixp"] > 70
    hit["slow_bleed"]         = inp["rsi"] < 30 and inp["ivix_abs"] < 17
    hit["deep_oversold_fear"] = inp["dist200"] < -5 and inp["rsi"] < 30 and inp["ivixp"] > 50
    hit["retest"]             = -1 <= inp["dist6mlow"] <= 3 and inp["rsi"] < 40
    hit["local_fear"]         = inp["ivixp"] > 50 and inp["uvixp"] < 50
    hit["momentum_bull"]      = inp["dist200"] > 0 and inp["bull"] >= 4
    hit["complacency"]        = inp["ivixp"] < 25 and inp["uvixp"] < 30 and inp["rsi"] > 65
    return [k for k in APP["scenario_order"] if hit.get(k)]

def composite(keys):
    S = APP["scenarios"]
    keys = [k for k in keys if S.get(k, {}).get("stats_all") and S[k]["stats_all"]["ret3"]["n"] >= 5]
    if not keys:
        return None
    def avg(f): return sum(f(S[k]["stats_all"]) for k in keys) / len(keys)
    return {"r1": avg(lambda s: s["ret1"]["med"]), "r3": avg(lambda s: s["ret3"]["med"]),
            "up1": avg(lambda s: s["ret1"]["up%"]), "up3": avg(lambda s: s["ret3"]["up%"]),
            "dip": avg(lambda s: s["dip3"]), "rally": avg(lambda s: s["rally3"]),
            "n": sum(S[k]["stats_all"]["ret3"]["n"] for k in keys), "keys": keys}

def confidence_bucket(raw3):
    cut = APP["quintile_cutoffs"]
    b = 0
    for i, c in enumerate(cut):
        if raw3 > c:
            b = i + 1
    return APP["quintiles"][b], b + 1

# ------------------------------------------------------------------ fetch latest (optional)
def fetch_latest():
    """Yahoo Finance se latest data laake input dict banata hai (yfinance + pandas chahiye)."""
    try:
        import pandas as pd, yfinance as yf
    except ImportError:
        sys.exit("--fetch ke liye: pip install yfinance pandas")
    t = {"^NSEI": "N", "^INDIAVIX": "IV", "^VIX": "UV"}
    frames = {}
    for tk, nm in t.items():
        d = yf.download(tk, period="3y", progress=False, auto_adjust=False)
        if hasattr(d.columns, "nlevels") and d.columns.nlevels > 1:
            d.columns = [c[0] for c in d.columns]
        frames[nm] = d["Close"]
    df = pd.DataFrame(frames).dropna(how="all").ffill()
    n, iv, uv = df["N"], df["IV"], df["UV"]
    # FIX: India 3:30 PM IST par close hota hai; US ka same-date close us raat aata hai.
    # Isliye US series ko 1 din shift karke use karo (warna look-ahead ho jayega).
    uv = uv.shift(1)
    pct = lambda s, w=252: float((s.iloc[-1] > s.iloc[-w-1:-1]).mean() * 100)  # FIX: aaj ka value khud se compare na ho; 252 pichhle din
    ema200 = n.ewm(span=200, adjust=False).mean()
    d = n.diff()
    up = d.clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    dn = (-d).clip(lower=0).ewm(alpha=1/14, adjust=False).mean()
    rsi = float(100 - 100 / (1 + up.iloc[-1] / dn.iloc[-1]))
    dist200 = float(100 * (n.iloc[-1] / ema200.iloc[-1] - 1))
    dd252 = float(100 * (n.iloc[-1] / n.iloc[-252:].max() - 1))
    d6 = float(100 * (n.iloc[-1] / n.iloc[-126:].min() - 1))
    atoms = {"ema200": dist200 > 0, "ema50": float(n.iloc[-1] / n.ewm(span=50, adjust=False).mean().iloc[-1] - 1) > 0,
             "golden": float(n.ewm(span=50, adjust=False).mean().iloc[-1] / ema200.iloc[-1] - 1) > 0,
             "weekly": n.iloc[-1] > n.resample("W-FRI").last().ewm(span=30, adjust=False).mean().iloc[-1],
             "rsi60": rsi > 60, "macd_pos": float((n.ewm(span=12, adjust=False).mean() - n.ewm(span=26, adjust=False).mean()).iloc[-1]
                                                  - (n.ewm(span=12, adjust=False).mean() - n.ewm(span=26, adjust=False).mean()).ewm(span=9, adjust=False).mean().iloc[-1]) > 0,
             "bothvixlow": pct(iv) < 30 and pct(uv) < 30}
    return {"date": str(df.index[-1].date()), "nifty": round(float(n.iloc[-1]), 2), "ivix_abs": round(float(iv.iloc[-1]), 2),
            "ivixp": round(pct(iv), 1), "uvix_abs": round(float(uv.iloc[-1]), 2), "uvixp": round(pct(uv), 1),
            "rsi": round(rsi, 1), "dist200": round(dist200, 2), "dd252": round(dd252, 2),
            "dist6mlow": round(d6, 2), "bull": sum(atoms.values()), "atoms": atoms}

# ------------------------------------------------------------------ report
def report(inp):
    pr = predict_probs(inp)
    P1, P3, PD, PRr = (pr[k]["cal"] for k in ["y_up_1M", "y_up_3M", "y_dip5_3M", "y_rally5_3M"])
    q, qi = confidence_bucket(pr["y_up_3M"]["raw"])
    keys = match_scenarios(inp)
    comp = composite(keys)
    M_avg = {"1M": 1.6, "3M": 4.2}   # model-bucket OOS averages
    r1 = 0.5 * comp["r1"] + 0.5 * M_avg["1M"] if comp else M_avg["1M"]
    r3 = 0.5 * comp["r3"] + 0.5 * M_avg["3M"] if comp else M_avg["3M"]
    N = inp["nifty"]

    L = []
    A = L.append
    A("=" * 74)
    A("  NIFTY MARKET SCENARIO PREDICTOR" + (f"   [{inp.get('date','')}]" if inp.get("date") else ""))
    A("=" * 74)
    A(f"Inputs : NIFTY {N:,.0f} | India VIX {inp['ivix_abs']} ({inp['ivixp']}th pct) | "
      f"US VIX {inp.get('uvix_abs','-')} ({inp['uvixp']}th pct)")
    A(f"         RSI14 {inp['rsi']} | 200-EMA se {inp['dist200']:+.2f}% | 52w-high se {inp['dd252']:+.2f}% | "
      f"6M-low se {inp['dist6mlow']:+.2f}% | bull-count {inp['bull']}/7")
    A("")
    A("PROBABILITIES (calibrated — ye use karo)")
    A(f"  P(NIFTY upar, next 1M)  : {100*P1:5.1f}%      (raw {100*pr['y_up_1M']['raw']:.1f}%, base rate {APP['calibration']['y_up_1M']['base_rate%']}%)")
    A(f"  P(NIFTY upar, next 3M)  : {100*P3:5.1f}%      (raw {100*pr['y_up_3M']['raw']:.1f}%, base rate {APP['calibration']['y_up_3M']['base_rate%']}%)")
    A(f"  P(3M me 5%+ ka dip)     : {100*PD:5.1f}%      (base rate 34%)")
    A(f"  P(3M me 5%+ ki rally)   : {100*PRr:5.1f}%      (base rate 62%)")
    A("")
    A(f"CONFIDENCE BUCKET: Q{qi}/5  ->  is bucket me historical 3M direction accuracy {q['accuracy%']}% (n={q['n']})")
    A("   " + ("Model confident zone me hai — bade tranche allowed." if qi >= 4 else
               "Model kam confident hai — position size chhota rakho." if qi <= 2 else
               "Model medium-confident hai — sirf tranche/SIP."))
    A("")
    A("MATCHED SCENARIOS")
    if keys:
        for k in keys:
            s, st = APP["scenarios"][k], APP["scenarios"][k]["stats_all"]
            A(f"  [{k}] {s['name']}")
            A(f"      rule: {s['rule']}")
            A(f"      history: 1M median {st['ret1']['med']:+.1f}% (up {st['ret1']['up%']:.0f}%), "
              f"3M median {st['ret3']['med']:+.1f}% (up {st['ret3']['up%']:.0f}%), "
              f"typ dip {st['dip3']}% / rally +{st['rally3']}%  |  n={st['events']} episodes")
            A(f"      action: {s['action']}")
    else:
        A("  (koi classical scenario match nahi hua — sirf model probabilities dekho)")
    A("")
    A("EXPECTED LEVELS (blended: 50% scenario median + 50% model bucket)")
    if comp:
        A(f"  Composite: 1M median {comp['r1']:+.2f}% (up {comp['up1']:.0f}%) | 3M median {comp['r3']:+.2f}% (up {comp['up3']:.0f}%)")
    A(f"  1M base        {r1:+6.2f}%  ->  {N*(1+r1/100):>10,.0f}")
    A(f"  3M base        {r3:+6.2f}%  ->  {N*(1+r3/100):>10,.0f}")
    if comp:
        A(f"  typical dip    {comp['dip']:+6.2f}%  ->  {N*(1+comp['dip']/100):>10,.0f}")
        A(f"  typical rally  {comp['rally']:+6.2f}%  ->  {N*(1+comp['rally']/100):>10,.0f}")
    A(f"  3M bad  tail   {-4.30:+6.2f}%  ->  {N*(1-0.043):>10,.0f}   (10th percentile)")
    A(f"  3M good tail   {+13.60:+6.2f}%  ->  {N*(1+0.136):>10,.0f}   (90th percentile)")
    A("")
    A("ACCURACY CONTEXT (walk-forward OOS 2020-2026, n=78 mahine)")
    ACC = APP["accuracy"]
    A(f"  NIFTY 3M direction : {ACC['nifty_dir_3M']}%  (baseline {ACC['nifty_base_3M']}%; AUC {ACC['dir3M_auc']})")
    A(f"  NIFTY 1M direction : {ACC['nifty_dir_1M']}%  (baseline {ACC['nifty_base_1M']}%)")
    A(f"  India VIX direction: {ACC['vix_direction_1M']}%  (baseline {ACC['vix_baseline']}%)")
    A(f"  Confidence Q5 accuracy: {APP['quintiles'][4]['accuracy%']}%  |  Q2: {APP['quintiles'][1]['accuracy%']}% (isliye sizing matter karta hai)")
    A("")
    A("Educational research only — investment advice nahi. Leverage se bachke.")
    A("=" * 74)
    return "\n".join(L)

def main():
    ap = argparse.ArgumentParser(description="NIFTY Market Scenario Predictor (standalone)")
    live = APP["live"]["inputs"]
    ap.add_argument("--fetch", action="store_true", help="Yahoo Finance se latest data (yfinance chahiye)")
    ap.add_argument("--nifty", type=float, default=live["nifty"])
    ap.add_argument("--vix", type=float, default=live["india_vix"], dest="ivix_abs")
    ap.add_argument("--vix-pct", type=float, default=live["india_vix_pct"], dest="ivixp")
    ap.add_argument("--us-vix-pct", type=float, default=live["us_vix_pct"], dest="uvixp")
    ap.add_argument("--rsi", type=float, default=live["rsi14"])
    ap.add_argument("--dist200", type=float, default=live["dist200"])
    ap.add_argument("--dd252", type=float, default=live["dd252"])
    ap.add_argument("--dist6mlow", type=float, default=live["dist6mlow"])
    ap.add_argument("--bull", type=int, default=live["bull_count"])
    a = ap.parse_args()
    inp = {"nifty": a.nifty, "ivix_abs": a.ivix_abs, "ivixp": a.ivixp, "uvixp": a.uvixp, "rsi": a.rsi,
           "dist200": a.dist200, "dd252": a.dd252, "dist6mlow": a.dist6mlow, "bull": a.bull}
    if a.fetch:
        f = fetch_latest()
        inp.update({k: f[k] for k in ["nifty", "ivix_abs", "ivixp", "uvixp", "rsi", "dist200", "dd252", "dist6mlow", "bull"]})
        inp["date"] = f["date"]
        if "uvix_abs" not in inp:
            inp["uvix_abs"] = f.get("uvix_abs", "-")
    else:
        live_atoms = APP["live"]["inputs"].get("atoms", {})
        inp["date"] = APP["meta"]["as_of"] + " (embedded snapshot)"
        inp["uvix_abs"] = live.get("us_vix", "-")     # FIX: US VIX level bhi print karo
    print(report(inp))

if __name__ == "__main__":
    main()
