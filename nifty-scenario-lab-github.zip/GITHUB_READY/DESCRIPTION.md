# NIFTY Market Scenario Predictor — Poori Description (Hinglish)

**Ye kya hai:** ek research-grade tool jo NIFTY 50 ke agle **1 se 3 mahine** ke scenario map karta hai —
kab girawat ka risk zyada hai, kab bounce/rally ka chance zyada hai — India VIX + US VIX + price
structure (RSI, MACD, EMA, Bollinger, drawdown, 52-week high/low, liquidity sweeps) ko mila kar.

**Aaj ki snapshot (as of 2026-10-01):**

| Input | Value | Kahan khada hai (252-din percentile) |
|---|---|---|
| NIFTY 50 | 22,422 | — |
| India VIX | 14.46 | 72.5th pct (market me dar **hai**, VIX girra nahi) |
| US VIX | 16.34 | 33.5th pct (US calm) |
| RSI-14 | 22.6 | **deep oversold** |
| 200-EMA se doori | −7.18% | 200-EMA ke neeche |
| 52-week high se | −14.84% | correction zone |
| 6-mahine low se | +0.00% | bilkul low par |
| Bull-count | 0 / 7 | saare strength atoms OFF |

**Model ka output (calibrated probabilities):**

* P(NIFTY upar, next **1 month**) = **65.8%** (base rate 64.1%)
* P(NIFTY upar, next **3 months**) = **83.8%** (base rate 66.7%)
* P(3M me 5%+ ka **dip**) = 35.3% (base rate 34%)
* P(3M me 5%+ ki **rally**) = 71.8% (base rate 62%)
* Confidence bucket: **Q5 / 5** (is bucket me historical 3M direction accuracy **93.8%**, n=16)
* Matched scenarios: **Slow Bleed**, **Deep Oversold + Fear**, **6M-Low Retest**, **Local Fear**
* Composite level estimate: 1M ≈ **+1.8%** (≈22,822) · 3M ≈ +3.7% (≈23,254) · typical worst dip ≈ −3.1% (≈21,735)

---

## 1. Kaam kaise karta hai (pipeline, step-by-step)

```
Yahoo Finance (^NSEI, ^INDIAVIX, ^VIX, ^GSPC)
        │
        ▼
[1] fetch_data.py     → data/MASTER.csv  (raw closes, 2016-12-01 → aaj)
        │
        ▼
[2] features.py       → data/features_daily.csv (74 features)
        │                 • India VIX %ile (252/756), VIX ka MA-distance, VRP z, IV/US-VIX ratio
        │                 • NIFTY: RSI5/14/2, Bollinger %B + bandwidth, MACD hist,
        │                   EMA20/50/100/200 distances, ATR%, realised vol, drawdown,
        │                   up-from-52w-low, RSI-divergence (bull/bear)
        │                 ★ US ka data 1 din shift (look-ahead fix — neeche §5 dekho)
        │
        ▼
[3] backtest.py → out/dataset_full.csv (91 features + forward targets)
        │            forward targets: ret_1M, ret_3M, fmin_3M (worst dip), fmax_3M (best rally)
        │            + liquidity-sweep events + signal-stats + lead-lag
        ▼
[4] sweeps.py → out/sweeps.csv  (swing high/low stop-hunts: sweep_low, sweep_high,
                  double_sweep, touch counts, days_since_sweep, close_pos, vol_z)
        │
        ▼
[5] diagnose.py → out/dataset_full.csv (forward min/max add) + VIX bucket/combo studies
        │
        ▼
[6] model_v2.py / walks.py / ensemble.py / calibrate.py / final_accuracy.py
        │   walk-forward validation: har mahine model retrain, 100-din embargo,
        │   OOS window 2020-01 → 2026-06 (78 months, ek-ek mahine ka independent test)
        ▼
[7] export_app_data.py → out/app_data.json  (model weights + calibration + scenario stats + presets)
        │
        ▼
[8] build_repo.py / build_github_ready.py → index.html (self-contained app), predict_nifty.py (CLI)
```

### 1.1 Final model (5 features — deep search ke baad yahi nikla)

`z = w · (x − mean)/scale + b`  →  `p_raw = sigmoid(z)`  →  `p_cal = sigmoid(a·logit(p_raw) + b)`

Features:

| Feature | Matlab |
|---|---|
| `iv_pct_252` | India VIX ka 252-din percentile (dar ka absolute level, normalised) |
| `uv_pct_252` | US VIX ka 252-din percentile (global risk, **1 din lagged**) |
| `n_dd_252` | NIFTY ka 52-week high se drawdown |
| `n_dist_ema200` | 200-EMA se % doori (trend + oversold ka mix) |
| `bull_count` | 7 strength atoms (200EMA, 50EMA, golden cross, weekly trend, RSI>60, MACD+, dono VIX calm) ka sum 0–7 |

4 targets alag-alag train hote hain: **up 1M**, **up 3M**, **5%+ dip (3M me)**, **5%+ rally (3M me)**.

Kyun 5 features hi? Kyunki **99,762 feature-combinations ka exhaustive search** kiya gaya —
in-sample top combos ka out-of-sample edge **zero** nikla (top decile IS 86.1% → OOS 65.8%,
baseline 66.7% se bhi kam). Yani zyada features = zyada overfit. Simple model jeeta.

### 1.2 Scenario engine (8 rules, episode-level)

Sirf probability nahi — "market abhi kaunse historical setup jaisa dikh raha hai" bhi batate hain:

| Scenario | Rule | 3M me kya hota aaya (median) |
|---|---|---|
| **Panic Washout** | 52w-high se −10%+ **aur** India VIX > 20 | +5.9% (17 episodes, 88% upar) |
| **Both-Market Panic** | India VIX%ile > 70 **aur** US VIX%ile > 70 | −0.2% (49 episodes, **50/50 — sabse kharab setup**) |
| **Slow Bleed** | RSI < 30 **par** India VIX < 17 | 1M +1.5%, **3M −1.7%** (11 episodes) |
| **Deep Oversold + Fear** | 200EMA se −5%+ **aur** RSI<30 **aur** VIX%ile>50 | +5.4% (7 episodes, 83% upar) |
| **6M-Low Retest** | 6-mahine low ke 3% andar **aur** RSI<40 | +6.3% (43 episodes, 71% upar) |
| **Local Fear** | India VIX%ile > 50 **par** US VIX%ile < 50 | +3.0% (76 episodes, 70% upar) |
| **Momentum Bull** | 200EMA ke upar **aur** bull-count ≥ 4 | +5.3% (78 episodes, 74% upar) |
| **Complacency** | dono VIX calm **aur** RSI > 65 | +5.0% (41 episodes, 81% upar) — par 1M me hedging sasti hoti hai |

Episode = consecutive din ko ek event me collapse kiya (warna "17 events" ki jagah 167 din count ho jate).

---

## 2. Market predict karne me ye kaise madad karta hai (practical use)

### 2.1 Confidence bucket ko position-size ka switch banao

OOS data me, model ki apni confidence ke hisaab se 3M direction accuracy:

| Bucket | Model ka avg prob | Actual 3M accuracy | n |
|---|---|---|---|
| Q1 (sabse kam confident) | 0.51 | 56.2% | 16 |
| Q2 | 0.73 | **46.7%** | 15 |
| Q3 | 0.83 | 62.5% | 16 |
| Q4 | 0.90 | 73.3% | 15 |
| **Q5 (sabse confident)** | 0.97 | **93.8%** | 16 |

**Rule:** Q5 me bada tranche allowed, Q1–Q2 me sirf chhoti SIP / wait. Aaj model **Q5** me hai.
Ye "signal" se zyada **position-sizing discipline** ka tool hai.

### 2.2 Aaj ke setup ka playbook (4 matched scenarios ka blend)

| Scenario | 1M median | 3M median | Kya karna hai |
|---|---|---|---|
| Slow Bleed | +1.5% | **−1.7%** | chhota starter hi; bada bet VIX 20+ washout par |
| Deep Oversold + Fear | +3.5% | +5.4% | tranche-1/2 deploy; stop 200EMA se 5% neeche weekly close |
| 6M-Low Retest | +1.7% | +6.3% | tranche-2; stop 6-mahine low ke neeche weekly close |
| Local Fear | +1.1% | +3.0% | accumulation zone (India-specific dar historically buyable) |

Blend: 1M median **+2.0% (78% up-rate)**, 3M median **+3.2% (67% up-rate)**,
typical worst dip **−3.1%**, typical best rally **+7.0%**.

### 2.3 Levels jinhe track karna hai

* **Upside:** 200-EMA (≈ 24,100 ke aas-paas) — reclaim hone par "Momentum Bull" scenario activate hoga,
  aur bull-count 4+ par switch ho jayega.
* **Downside:** 6-mahine low (aaj ≈ 22,400) — iske neeche weekly close = thesis fail, stop.
* **Fear gauge:** India VIX > 20 = washout zone (historical best 3M payoff), VIX < 17 + RSI<30 =
  "slow bleed" (bounce aayega par 3M me aksar aur neeche).

### 2.4 Risk-side ka numbers (jo log ignore karte hain)

* 3M me 5%+ dip: **35%** probability (base rate 34%) → yani "upar ka case strong hai" ka matlab
  "dip nahi aayega" **nahi** hai.
* Worst-case tail: 3M ka 5th-percentile dip ≈ **−4.3%** se leke deep-dip scenarios me −13%.
* Trade systems ki win-rate: sweep + VIX>50%ile = **75% (n=28)**, NIFTY >10% below 52w-high = 75% (n=12),
  VIX>20 = 73% (n=15) — par sample chhota hai, isliye inhe "edge" nahi, "tail-risk filter" maano.

### 2.5 Rozana ka workflow (3 minute)

1. `python3 predict_nifty.py --fetch` chalao (ya GitHub Actions se jo daily auto-update hota hai) —
   aaj ke inputs + 4 probabilities + matched scenarios + action plan print ho jayega.
2. Bucket dekho (Q1–Q5) → aaj ka position size decide karo.
3. Matched scenarios ka "action" line padho → entry/stop levels mil jayenge.
4. Har month-end par bucket change note karo (Q5 → Q3 girna = risk badhna).

---

## 3. Accuracy — kitna bharosa karein (honest scorecard)

Walk-forward OOS 2020-01 → 2026-06, n = 78 months (har month ka model sirf us waqt ka data dekhta hai):

| Kya predict karte hain | Accuracy | Baseline | Type |
|---|---|---|---|
| India VIX direction (1M) | **61.7%** | 44.7% | asli edge (+17 pp) |
| India VIX direction (2M) | 62.9% | 44.8% | asli edge |
| NIFTY direction 1M | 62.8% | 64.1% | baseline se kamzor |
| NIFTY direction 3M | 62.8% | 66.7% | hit-rate me edge nahi, **AUC 0.676** (ranking me hai) |
| 3M me 5%+ dip aayega? | 64.1% | 65.4% | AUC 0.57 |
| 3M me 5%+ rally aayegi? | 56.4% | 62.8% | AUC 0.607 |
| Sweep + VIX>50 system | 75% win | 65.3% (plain sweep) | trade-level, n=28 |
| Q5 bucket (3M direction) | **93.8%** | 66.7% | confidence filter |

**Seedhi baat:** point-direction hit-rate me model mostly baseline ke barabar hai. Asli value in
cheezon me hai → (a) VIX ki direction, (b) probability **ranking** (AUC), (c) high-confidence bucket
me 93.8%, (d) risk-side numbers (dip/rally), (e) position-sizing discipline.

**Aur ek honest caveat:** Platt-calibrated probabilities ka Brier score hold-out (aakhri 40% OOS)
par base-rate se sirf thoda better/same nikla — matlab "65.8%" ko 65.8% ki tarah treat karo,
"almost certain" ki tarah nahi. Model ka farak extreme buckets aur ranking me hai.

---

## 4. Kya kya files hain

### Repo (GitHub par jaane wala)

```
index.html               # pura app — self-contained (model weights + JS engine + charts embedded),
                         # zero external CDN, double-click karke chalta hai
predict_nifty.py         # standalone CLI — sirf python3 chahiye (koi library nahi)
data/app_data.json       # model weights, calibration, scenario stats, presets, live snapshot
data/live_forecast.json  # aaj ki probabilities (daily refresh se update hoti hain)
data/scenario_stats.csv  # 8 scenarios ki statistics
data/accuracy_scorecard.csv / confidence_buckets.csv
python/update_dashboard.py   # Yahoo se data laake dashboard khud refresh karta hai
.github/workflows/update.yml # weekday 18:00 IST par auto-refresh
DESCRIPTION.md / DESCRIPTION.txt / FIX_LOG.md  # ye documentation
```

### Research pipeline (`vixlab/`)

`fetch_data.py → features.py → backtest.py → sweeps.py → diagnose.py → model_v2.py → walks.py →
calibrate.py → ensemble.py → final_accuracy.py → export_app_data.py → build_repo.py → build_github_ready.py`
+ `done reports: report.html` (2 saal ki poori research, §1–§12) + `out/` me saare CSV/JSON/PNG.

**Chalane ka tareeka:**

```bash
# 1) sirf prediction dekhna hai (kuch install nahi karna):
python3 predict_nifty.py --fetch          # latest data khud laata hai (yfinance)
python3 predict_nifty.py                  # embedded snapshot par

# 2) dashboard daily khud update karna:
pip install yfinance pandas && python3 python/update_dashboard.py

# 3) GitHub par daalna:
#    naya repo banao → ye files upload karo → Settings → Pages → Deploy from branch: main / root
#    (steps START_HERE.txt me detail me hain)
```

---

## 5. Jo bugs mile aur fix kiye (summary — poora log FIX_LOG.md me)

23 findings mile. Sabse important 4 (jo number badal dete the):

1. **US data same-date par use ho raha tha (LOOK-AHEAD).** India 3:30 PM IST par band hota hai,
   US close us raat aata hai. Yani same-date US VIX "signal" future ka data tha.
   **Fix:** poori pipeline me US series 1 din shift (`US_LAG=1`), CLI/dashboard dono me bhi.
   Effect: same-date VIX-change correlation 0.236 → honest 0.169–0.184 (signal chhota hua, par asli).
2. **Sweep levels dobara count ho rahe the (double counting).** Ek baar sweep ho chuka level
   phir se "sweep" ban jata tha. **Fix:** level consume ho jata hai; touch sirf nearest level par.
   Effect: sweep_low_5d count 785 → 359 (matlab pehle ~2× inflated tha).
3. **RSI-divergence non-pivot values se compare ho raha tha.** **Fix:** sirf pivot-to-pivot comparison.
4. **Platt calibration usi OOS series par fit + evaluate ho raha tha** → Brier optimistic.
   **Fix:** 60% par fit, 40% par evaluate (honest Brier bhi report hota hai ab).

Baaki fixes: NIFTY index volume ke 0 ko "missing" treat kiya (fake vol spikes hatay), p-value
formula theek kiya (`z = 2|p−0.5|√n`), walks.py ka full-sample rank leak, `days_since_52w_high`
off-by-one (2106-din artifact), percentile windows (US lag + self-comparison), CLI me US VIX level
display bug, dashboard me live probabilities persistence, GitHub Actions ki commit-condition
fragility. Details + before/after numbers: **FIX_LOG.md**.

---

## 6. Limitations (jo ye tool NAHI kar sakta)

* **Events:** war, election result, policy shock, FII ban, budget — model inhe nahi jaanta;
  wo sirf tail probability me dikhte hain (deep-dip ~13%).
* **1-month direction:** practically unpredictable (62.8% vs 64.1% baseline). Short-term trading
  ke liye ye tool weak hai.
* **Regime shift:** model 2017–2026 ke India data par bana hai; agar market structure badle
  (jaise derivatives/position limits) to purane patterns kam kaam karenge.
* **Overlapping windows:** 63-din ke forward returns overlap karte hain, isliye 78 "independent"
  months asli me kam independent hain — effective sample 25–30 maano.
* **Selection bias:** 99,762 combos me se best chunna aasan tha; isliye final model simple rakha.

**Educational research tool hai — investment advice nahi. Leverage se bachke raho.
Apna risk khud manage karo.**

---

*Generated: 2026-10-04 · Data: 2016-12-01 → 2026-10-01 (2,427 trading days, 9.6 years) ·
Model: 5-feature logistic regression + Platt calibration, walk-forward OOS 2020–2026.*
