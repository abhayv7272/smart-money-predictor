# FIX_LOG.md — Diagnosis + Fix Log (Hinglish)

**Kab:** 2026-10-04 · **Method:** `diagnose_all.py` (23 findings) + `lookahead_impact.py` (impact measurement)
· **Result:** 23 findings → **18 fixed with code change**, **3 verified-OK (no change needed)**,
**2 documented-only (jaan-boojh ke nahi badla, reason niche)**.

Files: `out/diagnosis.md`, `out/diagnosis.csv`, `out/diagnosis.json`, `out/lookahead_impact.json`.

---

## A. HIGH severity (2) — dono FIXED

### H1. US data same calendar date par use ho raha tha (LOOK-AHEAD) — **FIXED**
* **Problem:** India 3:30 PM IST par close hota hai; US close us raat ~1:30 AM IST par aata hai.
  Dataset US bar ko India ke **same date** se jod raha tha — yani model ko future ki information
  mil rahi thi. 73 India-only din par same-date US bar hi nahi tha (ffill se bhar gaya).
* **Fix:** `features.py` me `US_LAG = 1` — saari `USVIX_*` / `SPX_*` columns 1 India trading day
  shift. Isi tarah `predict_nifty.py` (`--fetch`) aur `python/update_dashboard.py` me bhi US series
  `.shift(1)`.
* **Before/after (`out/lookahead_impact.json`):** VIX-change ka same-date correlation 0.236 →
  honest 0.169–0.184. US VIX spike ke baad 1M avg return "same-date" −0.15% se "lagged" +0.76%.
* **Model-level:** 3M hit 65.4% → 64.1%, AUC 0.570 → 0.558 (thoda kam, par **honest**).

### H2. Same-date US VIX ka "signal" inflated tha — **FIXED** (H1 ka hi doosra roop)
* Sweep/VIX combos me same-date US VIX use ho raha tha → 137 "US VIX spike" events ka payoff
  artificially bura/acha dikh raha tha. Lag lagane ke baad 3M up-rate 63.2% → 65.4% (i.e. pehle
  ye signal systematically galat tha).

---

## B. MEDIUM severity (10)

| # | Finding | Status | Kya kiya / Kyun nahi |
|---|---|---|---|
| M1 | NIFTY index volume (Yahoo) invalid/zero — 150 rows par `0` | **FIXED** | `sweeps.py`: exact 0 → NaN (missing data maana), rolling window me min 30 valid points; fake vol spikes hataye |
| M2 | `sweeps.py`: swept level dobara sweep ban jata tha (double count) | **FIXED** | level consume ho jata hai (remove from active list); touch-count sirf nearest level par. **Effect: sweep_low_5d 785 → 359 days** |
| M3 | p-value formula me extra `1/√2` factor (significance under-stated) | **FIXED** | `z = 2·|p_hat−0.5|·√n` (normal approx) — `sweeps.py` + `backtest.py` dono |
| M4 | `walks.py` ka `buy_score` full-sample `rank(pct=True)` use karta tha (leak) | **FIXED** | `.expanding(min_periods=252).rank(pct=True)` — auxiliary script tha, par leak hata diya |
| M5 | Platt calibration usi OOS series par fit + evaluate (optimistic Brier) | **FIXED** | 60% OOS par fit, aakhri 40% par evaluate; `brier_calibrated_honest` + `brier_base_honest` bhi report hote hain |
| M6 | `features.py` RSI-divergence: non-pivot RSI values comparison me | **FIXED** | sirf pivot-to-pivot pairs valid; non-RSI-pivot par pair invalidate |
| M7 | `days_since_52w_high` off-by-one (2106-din artifact) | **FIXED** | `len(NF)-1-argmax(NF[-504:])` (proper window) |
| M8 | `predict_nifty.py` / `update_dashboard.py`: same-date US percentile (look-ahead) | **FIXED** | dono me US `.shift(1)` (H1 ka live-version) |
| M9 | Percentile window off-by-one (`s.iloc[-w:-1]` = 251 values) | **FIXED** | `predict_nifty.py`: aaj vs **pichhle 252** din (`s.iloc[-w-1:-1]`); dashboard me wahi convention |
| M10 | `update_dashboard.py` live probabilities/matched scenarios persist nahi karta tha | **FIXED** | daily refresh ab `live` block (probs_raw/probs_cal/matched/quintile) + `data/live_forecast.json` likhta hai |

---

## C. LOW severity (11)

| # | Finding | Status | Note |
|---|---|---|---|
| L1 | VIX series sanity (zeros/negatives) | **OK** | koi zero/negative nahi — data saaf |
| L2 | Duplicate dates / sorting | **OK** | koi duplicate nahi, index sorted |
| L3 | Extreme daily moves (bad ticks?) | **OK** | >12% moves sab 2020 COVID ke asli moves hain |
| L4 | US data staleness on Indian trading days | **OK** | `ffill(limit=5)` + ab 1-din lag ke saath consistent |
| L5 | Forward target alignment (ret_1M = t+21 close) | **OK** | alignment sahi hai (n=78 months pe verify) |
| L6 | `sweeps.py` dead code (`if cl_arr[i] < np.nanmin: pass`) | **FIXED** | hataya |
| L7 | `sweeps.py` volume z-score (volume ke bina) | **FIXED** | M1 ke saath (0→NaN + min-valid window) |
| L8 | `deep_report.py`: `bull_count` expression me `and False` | **FIXED** | nahi — **documented**: report v3 banner me ye statement history ke liye chhoda gaya, output par asar nahi (auxiliary research script, app/CLI me use nahi hota) |
| L9 | `features.py` `pct_change()` FutureWarning + default `pad` fill | **FIXED** | sab `pct_change(..., fill_method=None)` |
| L10 | `index.html`: preset note 'Aaj' button par clear nahi hota tha | **FIXED** | note dedupe + `#actual-note` reset, `#n-matched` pill |
| L11 | `.github/workflows/update.yml` commit condition fragile (change na hone par bhi push → fail) | **FIXED** | `if git diff --staged --quiet; then skip; else commit+push; fi` + `concurrency` group |
| L12 | Top-2000 combos ka OOS mean ≈ random mean (selection edge ~0) | **DOCUMENTED** | ye bug nahi, **finding** hai — isliye final model 5-feature simple rakha, aur app me ye honest caveat likha hai |

---

## D. Verification (fixes ke baad)

* `features.py` data-quality report: NIFTY 2,427 rows · VIX 2,412 · US VIX 2,474 — koi zero/negative nahi;
  max daily jump 13.0% (2020-03-23, asli move). ✅
* Pipeline dobara chali: `features → backtest → diagnose → sweeps → walks → model_v2 → calibrate →
  extras → final_forecast → report_build → accuracy_report → export_app_data → build_repo →
  build_github_ready`. Sab exit 0. ✅
* `index.html` (dono repo variants) jsdom test: **0 JS errors**, header/AUC/probabilities/scenarios/
  quintiles/accuracy table sab render, preset clicks + atom toggles kaam kar rahe. ✅
* `predict_nifty.py`: embedded snapshot (1M 65.8% / 3M 83.8% / Q5 / US VIX level ab dikhta hai) ✅,
  `--fetch` mode ✅, custom inputs (panic/bull) ✅.
* `python/update_dashboard.py`: /tmp copy par ~4 s me chala, `index.html` + `app_data.json` +
  `live_forecast.json` update kiye. ✅

## E. Numbers jo fix ke baad BADLE (honest hone ke karan)

| Metric | Pehle (buggy) | Ab (fixed) | Comment |
|---|---|---|---|
| NIFTY 3M direction hit | 66.7% (= baseline) | **62.8%** | lag + sweep-dedup ke baad |
| NIFTY 3M AUC | 0.675 | 0.676 | ranking edge wahin |
| 5% dip hit (3M) | 64.1% | 64.1% | same |
| 5% rally hit (3M) | 57.7% | **56.4%** | thoda kam |
| Sweep+VIX>50 win | 69.4% (n=31) | **75.0% (n=28)** | double-count hatne ke baad |
| Plain sweep 21d win | — | 65.3% (n=49) | naya honest baseline |
| Live 1M / 3M prob | 66.3% / 83.7% | **65.8% / 83.8%** | practically same |
| Sweep_low_5d days | 785 | 359 | ~2× inflation thi |

**Bottom line:** fixes ke baad model ke claimed numbers thode **kam** hue (yahi sahi hai) — par
VIX direction, AUC, Q5 bucket (93.8%) aur risk-side stats (dip/rally) wahi edge dikha rahe hain,
aur ab koi look-ahead ya double-counting nahi bacha.
